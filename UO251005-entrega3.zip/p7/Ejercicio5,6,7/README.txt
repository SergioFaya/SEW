Este es el proyecto que he desarrollado para las entregas 5,6,7.En el cubro todos los
requisitos pedidos para esas entregas.

Utilizo jquery como lector de eventos en el menu de inicio del juego. Y para la generaci�n 
de c�digo din�micamente como insertar el canvas.
Utilizo ajax para cargar el script del juego ya que tenia que cargarlo despues de la 
carga inicial de la web.
Finalmente estoy usando el api canvas y el api fullscreen en el panel de juego.
Me hubiera gustado tambi�n meterle el api de web workers para que los controles de las raquetas fueran
as�ncronos pero por cuestiones de tiempo y dificultad no fu� capaz.

Ya que utilizo ajax para insertar el script este juego no funciona en local y 
tiene que ser desplegado en el servidor.



