document.getElementById("loadJson").onclick = function(){
    meteo.cargarDatos();
}