var asignatura = new Object();
asignatura.nombre = "Software y estándares en la Web";
asignatura.titulacion = "Grado en Ingenierí­a Informática del Software";
asignatura.centro = "Escuela de Ingeniería Informática";
asignatura.universidad = "Universidad de Oviedo";
asignatura.curso = "2017-18";
asignatura.estudiante = "Sergio Faya Fernández";
asignatura.email = "UO251005@uniovi.es";