document.write("Nombre navegador:  "+infoNavegador.nombre);
