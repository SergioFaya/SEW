﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;
using System.Xml;
using System.IO;

namespace XMLRecipesInput
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int pointerList = 0;
        XmlNodeList recipes; 
        public MainWindow()
        {
            InitializeComponent();
            rbtnGuardar.IsChecked = true;
            rdbtnEntrante.IsChecked = true;
            rdbtnFacil.IsChecked = true;
        }
        ~MainWindow()
        {
            Console.WriteLine("***Version de compilacion***");
            Console.WriteLine("****************************");
            Console.WriteLine("****************************");
            Console.WriteLine("****************************");
            Console.WriteLine(typeof(string).Assembly.ImageRuntimeVersion);
            Console.WriteLine("****************************");
            Console.WriteLine("****************************");
            Console.WriteLine("****************************");
            Console.WriteLine("****************************");
        }

        private void btnAñadir_Click(object sender, RoutedEventArgs e)
        {
            if (TextValid()) { 
                string nombre = txtNombre.Text;
                string cal = txtCalorias.Text;
                string tElaboracion = txtTiempoElaboracion.Text;
                string tipoPlato = GetTipoPlato();
                string dificultad = GetDificultad();
                string origen = txtOrigen.Text;
                string filename = txtNombreArchivo.Text;
                loadToDocument(filename,nombre, cal, tElaboracion, tipoPlato, dificultad, origen,
                    PrucessStringTxt(txtIngredientes), PrucessStringTxt(txtSteps),PrucessStringTxt(txtTools));
            }
            else {
                MessageBox.Show("Hay campos vacíos, el único campo vacío puede ser las calorías");
            }
        }

        public bool TextValid()
        {
            bool[] values = new bool[7];
            values[0] = txtIngredientes.Text.Trim() == "";
            values[1] = txtNombre.Text.Trim() == "";
            values[2] = txtNombreArchivo.Text.Trim() == "";
            values[3] = txtOrigen.Text.Trim() == "";
            values[4] = txtSteps.Text.Trim() == "";
            values[5] = txtTiempoElaboracion.Text.Trim() == "";
            values[6] = txtTools.Text.Trim() == "";
            bool variable = true;
            foreach (var item in values) {
                if (item == true) variable = false;
            }
            return variable;
        }

        private string[] PrucessStringTxt(TextBox txt)
        {
            char myChar = ',';
            if (txt.Equals(txtSteps)) {
                myChar = ';';
            }
            string[] steps = txt.Text.Split(myChar);
            return steps;
        }

        private string GetDificultad()
        {
            if (rdbtnDificil.IsChecked.Value) {
                return "Difícil";
            }else if (rdbtnMedio.IsChecked.Value) {
                return "Medio";
            }else if (rdbtnFacil.IsChecked.Value) {
                return "Fácil";
            }
            return "none";
        }

        private string GetTipoPlato()
        {
            if (rdbtnEntrante.IsChecked.Value) {
                return "Entrante";
            }
            else if(rdbtnPrimero.IsChecked.Value) {
                return "Primero";
            }
            else if (rdbtnSegundo.IsChecked.Value) {
                return "Segundo";
            }
            else if (rdbtnPostre.IsChecked.Value) {
                return "Postre";
            }
            return "none";
        }

        private void loadToDocument(string filename, string nombre, string cal, string tElaboracion, string tipoPlato, string dificultad, string origen,
            string[] ingredients, string[] steps, string[] tools)
        {
            if (!File.Exists(filename)) {//Create new file
                XmlDocument doc = new XmlDocument();
                XmlDeclaration dec = doc.CreateXmlDeclaration("1.0", "utf-8", null);
                doc.AppendChild(dec);
                XmlNode recipes = doc.CreateElement("recipes");
                doc.AppendChild(recipes);
                recipes.AppendChild(CreateRecipe(filename, nombre, cal, tElaboracion, tipoPlato, dificultad, origen,
                PrucessStringTxt(txtIngredientes), PrucessStringTxt(txtSteps), PrucessStringTxt(txtTools), doc));
                doc.Save(filename);
            }
            else {
                XmlDocument doc = new XmlDocument();
                XmlTextReader reader = new XmlTextReader(filename);
                XmlDeclaration dec = doc.CreateXmlDeclaration("1.0", "utf-8", null);
                reader.MoveToContent();
                doc.Load(reader);
                XmlNode recipes = doc.DocumentElement;
                XmlNode recipe = CreateRecipe(filename, nombre, cal, tElaboracion, tipoPlato, dificultad, origen,
                PrucessStringTxt(txtIngredientes), PrucessStringTxt(txtSteps), PrucessStringTxt(txtTools), doc);
                recipes.AppendChild(recipe);
                doc.InsertBefore(dec, recipes);
                reader.Close();
                doc.Save(filename);

            }
        }

        public void LoadRecipes(string filename)
        {
            XmlDocument doc = new XmlDocument();
            XmlTextReader reader = new XmlTextReader(filename);
            doc.Load(reader);
            XmlNode recipesNode = doc.DocumentElement;
            recipes = recipesNode.ChildNodes;
        }

        public void listRecipe(XmlNode recipe)
        { 
            txtNombre.Text = recipe.Attributes.GetNamedItem("nombre").InnerText;
            EnableRadioButton(recipe.Attributes.GetNamedItem("tipo").InnerText);
            EnableRadioButton(recipe.Attributes.GetNamedItem("dificultad").InnerText);
            txtCalorias.Text = recipe.Attributes.GetNamedItem("calorias").InnerText;
            txtTiempoElaboracion.Text = recipe.Attributes.GetNamedItem("tiempo_de_elaboracion").InnerText;
            XmlNodeList recipeContent = recipe.ChildNodes;
            XmlNode ingredients = recipeContent[0];
            txtIngredientes.Text = "";
            XmlNode steps = recipeContent[1];
            txtSteps.Text = "";
            XmlNode tools = recipeContent[2];
            txtTools.Text = "";
            XmlNode origin = recipeContent[3];
            foreach (XmlNode item in ingredients) {
                txtIngredientes.AppendText(item.Attributes.GetNamedItem("nombre").InnerText+
                    "- Cantidad: " +item.Attributes.GetNamedItem("cantidad").InnerText+"\n");
            }

            foreach (XmlNode item in steps) {
                txtSteps.AppendText(item.Attributes[0].InnerText + ".-" + item.InnerText + "\n");
            }

            foreach (XmlNode item in tools) {
                txtTools.AppendText("-"+item.Attributes[0].InnerText);
            }
            txtOrigen.Text = origin.InnerText;

        }

        public void EnableRadioButton(string buttonContent)
        {

            if (buttonContent == "Difícil") {
                rdbtnDificil.IsChecked = true;
            }
            else if (buttonContent == "Medio") {
                rdbtnMedio.IsChecked = true;
            }
            else if (buttonContent == "Fácil") {
                rdbtnFacil.IsChecked = true;
            }
            else if (buttonContent == "Entrante") {
                rdbtnEntrante.IsChecked = true;
            }
            else if (buttonContent == "Primero") {
                rdbtnPrimero.IsChecked = true;
            }
            else if (buttonContent == "Segundo") {
                rdbtnSegundo.IsChecked = true;
            }
            else if (buttonContent == "Postre") {
                rdbtnPostre.IsChecked = true;
            }
        }

        public XmlNode CreateRecipe(string filename, string nombre, string cal, string tElaboracion, string tipoPlato, string dificultad, string origen,
            string[] ingredients, string[] steps, string[] tools, XmlDocument doc)
        {
            XmlNode recipe = doc.CreateElement("recipe");
            XmlAttribute attribute = doc.CreateAttribute("nombre");
            attribute.Value = nombre;
            recipe.Attributes.Append(attribute);
            attribute = doc.CreateAttribute("tipo");
            attribute.Value = tipoPlato;
            recipe.Attributes.Append(attribute);
            attribute = doc.CreateAttribute("dificultad");
            attribute.Value = dificultad;
            recipe.Attributes.Append(attribute);
            attribute = doc.CreateAttribute("calorias");
            attribute.Value = cal;
            recipe.Attributes.Append(attribute);
            attribute = doc.CreateAttribute("tiempo_de_elaboracion");
            attribute.Value = tElaboracion;
            recipe.Attributes.Append(attribute);

            XmlNode ingredientsNode = doc.CreateElement("ingredients");
            try {
                foreach (var line in ingredients) {
                    XmlNode ingredient = doc.CreateElement("ingredient");
                    string[] lineSplit = line.Split(':');
                    string nombreIngredient = lineSplit[0];
                    string cantidadIngredient = lineSplit[1];
                    attribute = doc.CreateAttribute("nombre");
                    attribute.Value = nombreIngredient;
                    ingredient.Attributes.Append(attribute);
                    attribute = doc.CreateAttribute("cantidad");
                    attribute.Value = cantidadIngredient;
                    ingredient.Attributes.Append(attribute);
                    ingredientsNode.AppendChild(ingredient);
                }
            }
            catch (Exception e) {
                Console.WriteLine(e.Data);
                MessageBox.Show("Error en el formato de los ingredientes");
            }
            recipe.AppendChild(ingredientsNode);
            XmlNode cookingSteps = doc.CreateElement("cooking_steps");
            int count = 0;
            foreach (var line in steps) {
                count++;
                XmlNode step = doc.CreateElement("step");
                attribute = doc.CreateAttribute("numero");
                attribute.Value = count.ToString();
                step.Attributes.Append(attribute);
                step.InnerText = line;
                cookingSteps.AppendChild(step);
            }
            recipe.AppendChild(cookingSteps);
            XmlNode toolsNode = doc.CreateElement("tools");
            foreach (var item in tools) {
                XmlNode tool = doc.CreateElement("tool");
                attribute = doc.CreateAttribute("nombre");
                attribute.Value = item;
                tool.Attributes.Append(attribute);
                toolsNode.AppendChild(tool);
            }
            recipe.AppendChild(toolsNode);
            XmlNode origin = doc.CreateElement("origin");
            origin.InnerText = origen;
            recipe.AppendChild(origin); 
            return recipe;
        }

        private void btnAnterior_Click(object sender, RoutedEventArgs e)
        {
            if (pointerList == 1) {
                btnAnterior.IsEnabled = false;
            }
            btnSiguiente.IsEnabled = true;
            pointerList--;
            listRecipe(recipes[pointerList]);
            
            
        }

        private void btnSiguiente_Click(object sender, RoutedEventArgs e)
        {            
            if (pointerList < recipes.Count-1) {
                pointerList++;
                listRecipe(recipes[pointerList]);
                btnAnterior.IsEnabled = true;
            }
            else {
                btnSiguiente.IsEnabled = false;
            }
            
        }

        private void rbtnGuardar_Checked(object sender, RoutedEventArgs e)
        {
            txtCalorias.Text = "";
            txtIngredientes.Text = "Ejemplo de formato:\nCarne: 1k,Leche: 1 litro,\n Lechuga: 1,\nCalabacin: 3, etc...";
            txtNombre.Text = "";
            txtOrigen.Text = "";
            txtSteps.Text = "Ejemplo de Formato:\nEchar fabes a remojo ...;\nCocer.... ;\nServir;";
            txtTiempoElaboracion.Text = "Ejemplo formato datetime: PT6H(6 horas) PT3M(3 minutos)";
            txtTools.Text = "Ejemplo de formato: Pota, Cazo, Fuente etc...";
            btnAñadir.IsEnabled = true;
            btnAnterior.IsEnabled = false;
            btnSiguiente.IsEnabled = false;
        }

        private void rbtnView_Checked(object sender, RoutedEventArgs e)
        {
            LoadRecipes(txtNombreArchivo.Text);
            pointerList = 0;
            listRecipe(recipes[pointerList]);
            btnAñadir.IsEnabled = false;
            btnAnterior.IsEnabled = false;
            btnSiguiente.IsEnabled = true;
            btnLimpiar.IsEnabled = false;
        }

        private void btnLimpiar_Click(object sender, RoutedEventArgs e)
        {
            txtCalorias.Text = "";
            txtIngredientes.Text = "";
            txtNombre.Text = "";
            txtOrigen.Text = "";
            txtSteps.Text = "";
            txtTiempoElaboracion.Text = "";
            txtTools.Text = "";
            btnLimpiar.IsEnabled = true;
            rdbtnFacil.IsChecked = true;
            rdbtnEntrante.IsChecked = true;
        }
    }
}
